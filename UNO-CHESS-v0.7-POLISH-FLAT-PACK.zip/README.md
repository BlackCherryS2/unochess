# UNO CHESS Alpha v0.7 — POLISH

Product-polish build focused on identity, localization, audio and card feel.

- Main generated UNO CHESS logo used on home and Android launcher icon
- Korean / English / Japanese / Simplified Chinese UI + Quick Rules localization
- UNO-inspired card face language: four colors, white oval, strong corner/card silhouette
- Deal/flip animation and card draw SFX
- Fixed Web Audio unlock path so BGM begins after the first user interaction on Android WebView
- Ambient chord BGM + move/capture/check/chain/reverse/card effects
- Reverse whoosh synchronized with board rotation
- Existing PvP / AI / Chain Move / chess legality retained

Use GITHUB-PACKING-CODE.txt as `.github/workflows/build-apk.yml`. The workflow can build directly from the ZIP stored at repository root.
