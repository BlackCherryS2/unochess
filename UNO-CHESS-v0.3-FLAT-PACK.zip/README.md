# UNO CHESS — Alpha v0.3

Chess strategy meets a draw-driven turn system. Offline Android playtest build.

## v0.3
- UNO CHESS branding
- Korean / English UI with saved language preference
- infographic-first HUD and compact menus
- card flip / reverse-board motion retained
- promotion choice: Queen / Rook / Bishop / Knight
- compact Wild power selector
- responsive phone / tablet layout
- checkmate, stalemate, castling, en passant, Reverse Pawn rules and Choice Draw retained

## Build APK on GitHub
Upload the **contents** of this folder to the repository root. Open **Actions → Build UNO CHESS APK → Run workflow**. Download the `uno-chess-debug-apk` artifact after a successful build.

Android: minSdk 26, target/compileSdk 35.
