# UNO CHESS v0.9.3 — Refined Start

Polish/fix pack for the Android WebView build.

Key changes:
- Asset-safe logo rendering: `app_icon.png` is packaged into Android assets and broken-image glyphs are suppressed with a text fallback.
- Added the missing `MainActivity.java` directly to the flat pack.
- AI side assignment remains 50/50; WHITE always starts.
- Human BLACK games orient the board from BLACK's side before piece reveal.
- Start sequence: coin flip → YOU/AI side reveal → orientation → staggered piece spawn → WHITE draw/AI opening.
- STANDARD: each piece can move once per multi-move turn (Wild Dash exception).
- CHAIN: the same piece may move repeatedly.
- Pause/settings layers stay above moving-piece ghosts; active ghosts are hidden while menus are open.
- Home UI remains simplified around ruleset → opponent → PLAY.
- Four-language UI remains available (KO/EN/JA/ZH).
- GitHub workflow stages `UNO-CHESS-v0.9.3.apk` and verifies required web assets before build.

Audio note: built-in procedural chamber-style ambience/SFX remain offline-safe. `AUDIO-SOURCES.md` lists optional licensed replacement sources; do not redistribute third-party tracks unless their license has been checked for the intended release.


## v0.9.3 VISUAL TEMPO
- Central MOTION timing system for card, piece, AI, turn and signature FX pacing.
- Card reveal gets a longer readable hold without slowing touch feedback.
- Piece movement/capture use separate weighted timings.
- AI gets a short human-like think beat before each move.
- REVERSE/Wild Flip now perform a dedicated ~1s 180-degree board transition, while initial color assignment does not rotate the board.
- Start-piece spawn remains start-only.
- Reverse visuals and reverse pawn/promotion rules share the same state transition.
- AI thinking indicator follows the actual AI color.
