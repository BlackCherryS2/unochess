package com.unochess.game;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff090b12);WebView w=new WebView(this);w.setBackgroundColor(0xff090b12);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);w.setWebViewClient(new WebViewClient());w.setOverScrollMode(View.OVER_SCROLL_NEVER);w.loadUrl("file:///android_asset/index.html");setContentView(w);}
}
