# UNO CHESS Visual Tempo v0.9.3

Central timing values (milliseconds):
- Piece move: 360
- Capture: 430
- Card launch: 300
- Card flip: 280
- Card result hold: 520
- Card settle: 220
- AI think: 480–720
- AI between moves: 430
- Turn change: 320
- Chain accent: 420
- Check accent: 550
- Reverse signature transition: 1000
- Checkmate target beat: 1350
- Initial piece spawn: 820

Principle: input feedback remains immediate; only meaningful actions receive breathing room. Initial setup animation is isolated from normal render cycles. REVERSE is the intentional exception that rotates the board as a signature effect.
