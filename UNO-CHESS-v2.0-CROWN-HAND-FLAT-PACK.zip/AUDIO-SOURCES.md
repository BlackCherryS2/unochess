# UNO CHESS audio direction (v0.9)

The APK currently uses an improved offline Web Audio chamber-style fallback so the build remains self-contained.
For a production audio pass, replace the fallback with downloaded assets whose license is stored alongside the file.

Recommended source: Pixabay Content License
- BGM candidate: "Elegant" by AtlasAudio — Modern Classical / Solo Piano
  https://pixabay.com/music/modern-classical-elegant-522420/
- Chess/wood SFX search:
  https://pixabay.com/sound-effects/search/chess%20piece/
- Card flip/shuffle SFX search:
  https://pixabay.com/sound-effects/search/card%20flip/
- Coin flip SFX search:
  https://pixabay.com/sound-effects/search/coin%20flip/

Before shipping, keep the downloaded asset's source URL and license snapshot/record in the project.
