# UNO CHESS Alpha v0.8 — POLISH

Product-polish build focused on identity, localization, audio and card feel.

- Main generated UNO CHESS logo used on home and Android launcher icon
- Korean / English / Japanese / Simplified Chinese UI + Quick Rules localization
- UNO-inspired card face language: four colors, white oval, strong corner/card silhouette
- Deal/flip animation and card draw SFX
- Fixed Web Audio unlock path so BGM begins after the first user interaction on Android WebView
- Ambient chord BGM + move/capture/check/chain/reverse/card effects
- Reverse whoosh synchronized with board rotation
- Existing PvP / AI / Chain Move / chess legality retained

Use GITHUB-PACKING-CODE.txt as `.github/workflows/build-apk.yml`. The workflow can build directly from the ZIP stored at repository root.

## v0.8 FAIR START
- STANDARD (default): a piece may move only once per card-turn; Wild DASH is the exception.
- CHAIN: repeated movement of the same piece is allowed.
- Opening normal moves removed.
- Animated coin flip assigns sides; White starts and draws a card immediately.
- Number balance: 0–3 = 1 move, 4–8 = 2 moves, 9 = 3 moves.
