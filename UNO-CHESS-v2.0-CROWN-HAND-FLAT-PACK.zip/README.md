# UNO CHESS v1.2 — DOUBLE LOCK

Android/WebView flat source pack for `com.unochess.game`.

## Core rules
- 0–3 = 1 MOVE, 4–8 = 2 MOVES, 9 = 3 MOVES.
- STANDARD: the same piece cannot move twice in one multi-move turn.
- CHAIN: the same piece may move repeatedly.
- SKIP ends the turn; while in check it becomes Guard with one legal response.
- REVERSE performs the board-direction reversal and changes pawn travel/promotion direction.
- +2 DOUBLE LOCK: choose two enemy non-king pieces, lock them for their next turn, and your own current turn is fixed to 1 MOVE.
- WILD: MARK / LOCK / SWAP / REVERSE.

## v1.2 focus
The old +2 Choice Draw system has been removed. +2 is now an offensive debuff. AI evaluates and applies the same rule, and lock lifetime is tracked separately from STANDARD's per-turn moved-piece state.

See `V1.2-RELEASE-NOTES.md` for details.

## v2.0 CROWN HAND
Adds a full hand-management mode with 7-card opening hands, optional card play, ONE! calls, king/crown scoring, score reveal, and hand-aware AI. See V2.0-RELEASE-NOTES.md.
